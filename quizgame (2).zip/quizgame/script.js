const questions = [
    {
      question: "What is the capital of India?",
      answers: ["Delhi", "Mumbai", "Kolkata", "Chennai"],
      correct: "Delhi"
    },
    {
      question: "Which planet is known as the Red Planet?",
      answers: ["Earth", "Mars", "Jupiter", "Venus"],
      correct: "Mars"
    },
    {
      question: "What is 5 + 3?",
      answers: ["5", "8", "10", "7"],
      correct: "8"
    }
  ];
  
  const questionEl = document.getElementById("question");
  const answerButtonsEl = document.getElementById("answer-buttons");
  const nextBtn = document.getElementById("next-btn");
  
  let currentQuestionIndex = 0;
  let score = 0;
  
  function showQuestion() {
    resetState();
    const currentQuestion = questions[currentQuestionIndex];
    questionEl.textContent = currentQuestion.question;
  
    currentQuestion.answers.forEach(answer => {
      const button = document.createElement("button");
      button.textContent = answer;
      button.addEventListener("click", () => selectAnswer(button, currentQuestion.correct));
      answerButtonsEl.appendChild(button);
    });
  }
  
  function resetState() {
    nextBtn.style.display = "none";
    answerButtonsEl.innerHTML = "";
  }
  
  function selectAnswer(button, correctAnswer) {
    const isCorrect = button.textContent === correctAnswer;
    if (isCorrect) {
      button.classList.add("correct");
      score++;
    } else {
      button.classList.add("wrong");
    }
  
    Array.from(answerButtonsEl.children).forEach(btn => {
      btn.disabled = true;
      if (btn.textContent === correctAnswer) {
        btn.classList.add("correct");
      }
    });
  
    nextBtn.style.display = "inline-block";
  }
  
  nextBtn.addEventListener("click", () => {
    currentQuestionIndex++;
    if (currentQuestionIndex < questions.length) {
      showQuestion();
    } else {
      showScore();
    }
  });
  
  function showScore() {
    resetState();
    questionEl.textContent = `Quiz Complete! You scored ${score} out of ${questions.length}.`;
    nextBtn.textContent = "Play Again";
    nextBtn.style.display = "inline-block";
    nextBtn.onclick = () => {
      location.reload();
    };
  }
  
  showQuestion();
  